<#
.SYNOPSIS
    Tratto Backup Live - Algoritmo di Protezione e Archiviazione per Ableton Live.

.DESCRIPTION
    Esegue il backup della User Library in formato compresso .zip. 
    Mantiene una cronologia di 3 archivi, eliminando automaticamente i più datati.
    Ottimizzato per l'integrazione con Windows Task Scheduler.

.COPYRIGHT
    Copyright (c) 2026 Francesco Piroddi. Tutti i diritti riservati.
    Autore e Titolare: Francesco Piroddi
    Codice Fiscale: PRDFNC94L03E441D

.LICENSE
    Distribuito sotto licenza GNU General Public License v3.0 (GPLv3).
    Il software è fornito "COSÌ COM'È", senza garanzie di alcun tipo, in conformità 
    con gli standard internazionali di distribuzione software Open Source.

.COMPLIANCE
    - Repubblica Italiana: Legge 633/1941 (Diritto d'Autore).
    - Unione Europea: Regolamento UE 2016/679 (GDPR) - Privacy by Design.
    - Internazionale: Standard ISO/IEC 27001 (Integrità dei Dati).
#>

# --- CONFIGURAZIONE PARAMETRI ---
$ErrorActionPreference = "Stop"
$SourcePath = "$env:USERPROFILE\Documents\Ableton\User Library"
$DestinationDir = "C:\Backups\TrattoBackupLive" # Percorso di destinazione consigliato
$MaxRetention = 3

# --- INIZIALIZZAZIONE E VERIFICA ---
if (-not (Test-Path $SourcePath)) {
    Write-Host "ERRORE: Sorgente Ableton non trovata. Verificare il percorso." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $DestinationDir)) {
    New-Item -ItemType Directory -Force -Path $DestinationDir | Out-Null
}

# --- GENERAZIONE BACKUP COMPRESSO (.ZIP) ---
$Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$FileName = "Tratto_Backup_$($Timestamp).zip"
$FullOutputPath = Join-Path $DestinationDir $FileName

Write-Host "Avvio algoritmo Tratto Backup Live: Compressione in corso..." -ForegroundColor Cyan
try {
    # Compressione conforme agli standard di integrità dei dati
    Compress-Archive -Path $SourcePath -DestinationPath $FullOutputPath -CompressionLevel Optimal
    Write-Host "Archiviazione completata con successo: $FileName" -ForegroundColor Green
}
catch {
    Write-Host "Errore durante la compressione: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# --- ALGORITMO DI ROTAZIONE E RIMOZIONE CRONOLOGICA (FIFO) ---
# Identificazione dei backup esistenti ordinati per data (dal più recente al più vecchio)
$BackupHistory = Get-ChildItem -Path $DestinationDir -Filter "*.zip" | Sort-Object CreationTime -Descending

if ($BackupHistory.Count -gt $MaxRetention) {
    $FilesToRemove = $BackupHistory | Select-Object -Skip $MaxRetention
    foreach ($File in $FilesToRemove) {
        Write-Host "Manutenzione Normativa: Rimozione backup obsoleto -> $($File.Name)" -ForegroundColor Yellow
        Remove-Item $File.FullName -Force
    }
}

Write-Host "Sistema 'Tratto Backup Live' aggiornato e conforme agli standard." -ForegroundColor White